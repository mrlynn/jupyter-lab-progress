
# lab-utils

A lightweight Python library to standardize Jupyter lab progress, validation, and messaging for your labs or workshops.

## Usage

```python
from lab_utils import LabProgress, LabValidator, show_info

progress = LabProgress(["Load Data", "Index", "Query"])
progress.mark_done("Load Data")

show_info("Next we will index vectors.")

validator = LabValidator()
validator.check_embedding_shape([0.1]*384, 384)
```
