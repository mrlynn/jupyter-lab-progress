
class LabValidator:
    def check_embedding_shape(self, embedding, expected_dim):
        if len(embedding) != expected_dim:
            raise ValueError(f"Embedding shape mismatch: got {len(embedding)}, expected {expected_dim}")
        print(f"✅ Embedding shape is correct: {len(embedding)}")

    def assert_in_dataframe(self, df, column, value):
        if value not in df[column].values:
            raise ValueError(f"{value} not found in column {column}")
        print(f"✅ Found {value} in {column}")
