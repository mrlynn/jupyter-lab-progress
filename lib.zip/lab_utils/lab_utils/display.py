
from IPython.display import display, HTML

def show_info(message):
    display(HTML(f"""
    <div style='background-color: #e7f3ff; border-left: 6px solid #2196F3; padding: 10px; margin: 10px 0;'>
    {message}
    </div>
    """))

def show_warning(message):
    display(HTML(f"""
    <div style='background-color: #fff3cd; border-left: 6px solid #ffecb5; padding: 10px; margin: 10px 0;'>
    ⚠️ {message}
    </div>
    """))
