
from IPython.display import display, HTML

class LabProgress:
    def __init__(self, steps):
        self.steps = {step: False for step in steps}
        self.display_progress()

    def mark_done(self, step):
        if step in self.steps:
            self.steps[step] = True
            self.display_progress()
        else:
            print(f"⚠️ Unknown step: {step}")

    def display_progress(self):
        html = "<ul>"
        for step, done in self.steps.items():
            color = "#4CAF50" if done else "#F44336"
            icon = "✅" if done else "⏳"
            html += f"<li style='color:{color};'>{icon} {step}</li>"
        html += "</ul>"
        display(HTML(html))
